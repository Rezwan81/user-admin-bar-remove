<?php
/**
 * @package user admin bar remove
 */
/*

Plugin Name: user admin bar remove
Plugin URI: https://devles.com/
Description: This is wordpress user admin bar removebal from frontend pages 
Author: Rezwan Shiblu
Author URI: https://devles.com/
Version: 1.0
License: GPLv2 or later
Text Domain: user admin bar remove
*/


/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Rezwan,Sylhet, Bangladesh.

Copyright 2020.
*/

//user admin bar modification

function remove_admin_bar() {
show_admin_bar(false);
}
add_action('after_setup_theme', 'remove_admin_bar');



